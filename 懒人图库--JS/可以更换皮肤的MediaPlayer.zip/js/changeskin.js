<!--
function ShowButtons(n){
n = parseInt(n);
with(document) {
	switch (n) {
		case 1: var strpZone = "<div id=pBox><img src=skin/index/pBox.gif width=23 height=8 alt=�ƶ��������ӰƬ���� /></div>";
		var strbtnPlayStop = "<img src=skin/index/BtnPlay.gif alt=����/��ͣ name=playControl width=36 height=21 border=0 id=playControl onClick=toPlay() style=cursor:pointer />";
		var strbtnPlayPause = "<img src=skin/index/BtnStop.gif width=34 height=21 border=0 style=cursor:pointer onClick=toStop() alt=ֹͣ/>";
		var strbtnFullScrean = "<img src=skin/index/BtnFullScrean.gif width=29 height=21 border=0 style=cursor:pointer onClick=fullScreen() alt=ȫ�� />";
		var strbtnOffOnSound = "<img src=skin/index/BtnOnSound.gif alt=�������� name=muteControl width=32 height=21 border=0 id=muteControl style=cursor:pointer onClick=toMute() />";
		var strvZone = "<div id=vBox><img src=skin/index/BtnSoundCtrBar.gif width=5 height=13 alt=�ƶ��������������С /></div>";
		getObject('pZone').innerHTML = strpZone;
		getObject('btnPlayStop').innerHTML = strbtnPlayStop;
		getObject('btnPlayPause').innerHTML = strbtnPlayPause;
		getObject('btnFullScrean').innerHTML = strbtnFullScrean;
		getObject('btnOffOnSound').innerHTML = strbtnOffOnSound;
		getObject('vZone').innerHTML = strvZone;
		break;
		case 2: var strpZone = "<div id=pBox><img src=skin/green/pBox.gif width=23 height=8 alt=�ƶ��������ӰƬ���� /></div>";
		var strbtnPlayStop = "<img src=skin/green/BtnPlay.gif alt=����/��ͣ name=playControl width=36 height=21 border=0 id=playControl onClick=toPlay() style=cursor:pointer />";
		var strbtnPlayPause = "<img src=skin/green/BtnStop.gif width=34 height=21 border=0 style=cursor:pointer onClick=toStop() alt=ֹͣ/>";
		var strbtnFullScrean = "<img src=skin/green/BtnFullScrean.gif width=29 height=21 border=0 style=cursor:pointer onClick=fullScreen() alt=ȫ�� />";
		var strbtnOffOnSound = "<img src=skin/green/BtnOnSound.gif alt=�������� name=muteControl width=32 height=21 border=0 id=muteControl style=cursor:pointer onClick=toMute() />";
		var strvZone = "<div id=vBox><img src=skin/green/BtnSoundCtrBar.gif width=5 height=13 alt=�ƶ��������������С /></div>";
		getObject('pZone').innerHTML = strpZone;
		getObject('btnPlayStop').innerHTML = strbtnPlayStop;
		getObject('btnPlayPause').innerHTML = strbtnPlayPause;
		getObject('btnFullScrean').innerHTML = strbtnFullScrean;
		getObject('btnOffOnSound').innerHTML = strbtnOffOnSound;
		getObject('vZone').innerHTML = strvZone;
		break;
		case 3: var strpZone = "<div id=pBox><img src=skin/yellow/pBox.gif width=23 height=8 alt=�ƶ��������ӰƬ���� /></div>";
		var strbtnPlayStop = "<img src=skin/yellow/BtnPlay.gif alt=����/��ͣ name=playControl width=36 height=21 border=0 id=playControl onClick=toPlay() style=cursor:pointer />";
		var strbtnPlayPause = "<img src=skin/yellow/BtnStop.gif width=34 height=21 border=0 style=cursor:pointer onClick=toStop() alt=ֹͣ/>";
		var strbtnFullScrean = "<img src=skin/yellow/BtnFullScrean.gif width=29 height=21 border=0 style=cursor:pointer onClick=fullScreen() alt=ȫ�� />";
		var strbtnOffOnSound = "<img src=skin/yellow/BtnOnSound.gif alt=�������� name=muteControl width=32 height=21 border=0 id=muteControl style=cursor:pointer onClick=toMute() />";
		var strvZone = "<div id=vBox><img src=skin/yellow/BtnSoundCtrBar.gif width=5 height=13 alt=�ƶ��������������С /></div>";
		getObject('pZone').innerHTML = strpZone;
		getObject('btnPlayStop').innerHTML = strbtnPlayStop;
		getObject('btnPlayPause').innerHTML = strbtnPlayPause;
		getObject('btnFullScrean').innerHTML = strbtnFullScrean;
		getObject('btnOffOnSound').innerHTML = strbtnOffOnSound;
		getObject('vZone').innerHTML = strvZone;
		break;
		case 4: var strpZone = "<div id=pBox><img src=skin/purple/pBox.gif width=23 height=8 alt=�ƶ��������ӰƬ���� /></div>";
		var strbtnPlayStop = "<img src=skin/purple/BtnPlay.gif alt=����/��ͣ name=playControl width=36 height=21 border=0 id=playControl onClick=toPlay() style=cursor:pointer />";
		var strbtnPlayPause = "<img src=skin/purple/BtnStop.gif width=34 height=21 border=0 style=cursor:pointer onClick=toStop() alt=ֹͣ/>";
		var strbtnFullScrean = "<img src=skin/purple/BtnFullScrean.gif width=29 height=21 border=0 style=cursor:pointer onClick=fullScreen() alt=ȫ�� />";
		var strbtnOffOnSound = "<img src=skin/purple/BtnOnSound.gif alt=�������� name=muteControl width=32 height=21 border=0 id=muteControl style=cursor:pointer onClick=toMute() />";
		var strvZone = "<div id=vBox><img src=skin/purple/BtnSoundCtrBar.gif width=5 height=13 alt=�ƶ��������������С /></div>";
		getObject('pZone').innerHTML = strpZone;
		getObject('btnPlayStop').innerHTML = strbtnPlayStop;
		getObject('btnPlayPause').innerHTML = strbtnPlayPause;
		getObject('btnFullScrean').innerHTML = strbtnFullScrean;
		getObject('btnOffOnSound').innerHTML = strbtnOffOnSound;
		getObject('vZone').innerHTML = strvZone;
		break;
		case 5: var strpZone = "<div id=pBox><img src=skin/coffee/pBox.gif width=23 height=8 alt=�ƶ��������ӰƬ���� /></div>";
		var strbtnPlayStop = "<img src=skin/coffee/BtnPlay.gif alt=����/��ͣ name=playControl width=36 height=21 border=0 id=playControl onClick=toPlay() style=cursor:pointer />";
		var strbtnPlayPause = "<img src=skin/coffee/BtnStop.gif width=34 height=21 border=0 style=cursor:pointer onClick=toStop() alt=ֹͣ/>";
		var strbtnFullScrean = "<img src=skin/coffee/BtnFullScrean.gif width=29 height=21 border=0 style=cursor:pointer onClick=fullScreen() alt=ȫ�� />";
		var strbtnOffOnSound = "<img src=skin/coffee/BtnOnSound.gif alt=�������� name=muteControl width=32 height=21 border=0 id=muteControl style=cursor:pointer onClick=toMute() />";
		var strvZone = "<div id=vBox><img src=skin/coffee/BtnSoundCtrBar.gif width=5 height=13 alt=�ƶ��������������С /></div>";
		getObject('pZone').innerHTML = strpZone;
		getObject('btnPlayStop').innerHTML = strbtnPlayStop;
		getObject('btnPlayPause').innerHTML = strbtnPlayPause;
		getObject('btnFullScrean').innerHTML = strbtnFullScrean;
		getObject('btnOffOnSound').innerHTML = strbtnOffOnSound;
		getObject('vZone').innerHTML = strvZone;
		break;
		case 6: var strpZone = "<div id=pBox><img src=skin/pink/pBox.gif width=23 height=8 alt=�ƶ��������ӰƬ���� /></div>";
		var strbtnPlayStop = "<img src=skin/pink/BtnPlay.gif alt=����/��ͣ name=playControl width=36 height=21 border=0 id=playControl onClick=toPlay() style=cursor:pointer />";
		var strbtnPlayPause = "<img src=skin/pink/BtnStop.gif width=34 height=21 border=0 style=cursor:pointer onClick=toStop() alt=ֹͣ/>";
		var strbtnFullScrean = "<img src=skin/pink/BtnFullScrean.gif width=29 height=21 border=0 style=cursor:pointer onClick=fullScreen() alt=ȫ�� />";
		var strbtnOffOnSound = "<img src=skin/pink/BtnOnSound.gif alt=�������� name=muteControl width=32 height=21 border=0 id=muteControl style=cursor:pointer onClick=toMute() />";
		var strvZone = "<div id=vBox><img src=skin/pink/BtnSoundCtrBar.gif width=5 height=13 alt=�ƶ��������������С /></div>";
		getObject('pZone').innerHTML = strpZone;
		getObject('btnPlayStop').innerHTML = strbtnPlayStop;
		getObject('btnPlayPause').innerHTML = strbtnPlayPause;
		getObject('btnFullScrean').innerHTML = strbtnFullScrean;
		getObject('btnOffOnSound').innerHTML = strbtnOffOnSound;
		getObject('vZone').innerHTML = strvZone;
		break;
		case 7: var strpZone = "<div id=pBox><img src=skin/redcoffee/pBox.gif width=23 height=8 alt=�ƶ��������ӰƬ���� /></div>";
		var strbtnPlayStop = "<img src=skin/redcoffee/BtnPlay.gif alt=����/��ͣ name=playControl width=36 height=21 border=0 id=playControl onClick=toPlay() style=cursor:pointer />";
		var strbtnPlayPause = "<img src=skin/redcoffee/BtnStop.gif width=34 height=21 border=0 style=cursor:pointer onClick=toStop() alt=ֹͣ/>";
		var strbtnFullScrean = "<img src=skin/redcoffee/BtnFullScrean.gif width=29 height=21 border=0 style=cursor:pointer onClick=fullScreen() alt=ȫ�� />";
		var strbtnOffOnSound = "<img src=skin/redcoffee/BtnOnSound.gif alt=�������� name=muteControl width=32 height=21 border=0 id=muteControl style=cursor:pointer onClick=toMute() />";
		var strvZone = "<div id=vBox><img src=skin/redcoffee/BtnSoundCtrBar.gif width=5 height=13 alt=�ƶ��������������С /></div>";
		getObject('pZone').innerHTML = strpZone;
		getObject('btnPlayStop').innerHTML = strbtnPlayStop;
		getObject('btnPlayPause').innerHTML = strbtnPlayPause;
		getObject('btnFullScrean').innerHTML = strbtnFullScrean;
		getObject('btnOffOnSound').innerHTML = strbtnOffOnSound;
		getObject('vZone').innerHTML = strvZone;
		break;
		case 8: var strpZone = "<div id=pBox><img src=skin/greenblue/pBox.gif width=23 height=8 alt=�ƶ��������ӰƬ���� /></div>";
		var strbtnPlayStop = "<img src=skin/greenblue/BtnPlay.gif alt=����/��ͣ name=playControl width=36 height=21 border=0 id=playControl onClick=toPlay() style=cursor:pointer />";
		var strbtnPlayPause = "<img src=skin/greenblue/BtnStop.gif width=34 height=21 border=0 style=cursor:pointer onClick=toStop() alt=ֹͣ/>";
		var strbtnFullScrean = "<img src=skin/greenblue/BtnFullScrean.gif width=29 height=21 border=0 style=cursor:pointer onClick=fullScreen() alt=ȫ�� />";
		var strbtnOffOnSound = "<img src=skin/greenblue/BtnOnSound.gif alt=�������� name=muteControl width=32 height=21 border=0 id=muteControl style=cursor:pointer onClick=toMute() />";
		var strvZone = "<div id=vBox><img src=skin/greenblue/BtnSoundCtrBar.gif width=5 height=13 alt=�ƶ��������������С /></div>";
		getObject('pZone').innerHTML = strpZone;
		getObject('btnPlayStop').innerHTML = strbtnPlayStop;
		getObject('btnPlayPause').innerHTML = strbtnPlayPause;
		getObject('btnFullScrean').innerHTML = strbtnFullScrean;
		getObject('btnOffOnSound').innerHTML = strbtnOffOnSound;
		getObject('vZone').innerHTML = strvZone;
		break;
	}
}
}

// *** Cookies ***
function writeCookie(name, value) { 
	exp = new Date(); 
	exp.setTime(exp.getTime() + (86400 * 1000 * 30));
	document.cookie = name + "=" + escape(value) + "; expires=" + exp.toGMTString() + "; path=/"; 
} 
function readCookie(name) { 
	var search; 
	search = name + "="; 
	offset = document.cookie.indexOf(search); 
	if (offset != -1) { 
		offset += search.length; 
		end = document.cookie.indexOf(";", offset); 
		if (end == -1){
			end = document.cookie.length;
		}
		return unescape(document.cookie.substring(offset, end)); 
	}else{
		return "";
	}
}

function getObject(objectId) {
    if(document.getElementById && document.getElementById(objectId)) {
	// W3C DOM
	return document.getElementById(objectId);
    } else if (document.all && document.all(objectId)) {
	// MSIE 4 DOM
	return document.all(objectId);
    } else if (document.layers && document.layers[objectId]) {
	// NN 4 DOM.. note: this won't find nested layers
	return document.layers[objectId];
    } else {
	return false;
    }
}

function pageOptions(){
    if (getObject('Sright').style.visibility == "hidden") {
	getObject('Sright').style.visibility="visible"}
	else
	{getObject('Sright').style.visibility="hidden"}
}

function ChangeSkin(n)
{
writecookie(n);
ShowButtons(n);
getObject('cssfile').href="skin/player"+n+".css";
getObject('jsPlayer').src="js/player"+n+".js";
getObject('tong').src="images/tong"+n+".gif";
getObject('curMediaColor').src="images/mColor"+n+".gif";
}

function writecookie(n)
{
if (n=="") {n=1}
var expires = new Date();
expires.setTime(expires.getTime() + 24*60*60*365*1000);
var flag = "sohu_ChinaRen_alumni="+n;
document.cookie=flag+";expires="+expires.toGMTString();
}
 
function readcookie()
{
var j = 0
var mycookie = document.cookie;
var name = "sohu_ChinaRen_alumni"
var start1 = mycookie.indexOf(name+"=");
if (start1== -1)
	{j=1}
else{
start=mycookie.indexOf("=",start1)+1; 
var end = mycookie.indexOf(";",start);
	if (end==-1)
	{
 	end=mycookie.length;
	}
 var value=unescape(mycookie.substring(start,end));
 if (value==null)
 {j=1}
 else
 {j=value}
 }
 ChangeSkin(j)
 return j;
}
-->